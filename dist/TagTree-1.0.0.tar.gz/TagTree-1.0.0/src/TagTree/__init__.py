from .template import Tag
from .Document import Document

__all__ = ['Tag', 'Document']